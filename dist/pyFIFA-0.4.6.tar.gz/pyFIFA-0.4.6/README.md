# OOP-Fifa-In-Terminal
Codebase for terminal text based version of fifa my player career mode. 
