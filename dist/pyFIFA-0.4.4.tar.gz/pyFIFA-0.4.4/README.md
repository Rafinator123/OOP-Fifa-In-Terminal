PyFIFA is an interactive text-based soccer game inspired by the 2023 FIFA World 
Cup in Qatar. Please press the Enter/Return button on your keyboard to start the 
game and initate character creation. We hope you enjoy!

This package was created by:
Alex Hmitti
Rafael-Nadal Scala
Aaron Stein :)

Github:
https://github.com/Rafinator123/OOP-Fifa-In-Terminal


To run this project first install it with:
``pip install pyFIFA``

Then simply type in the following command to run it in your terminal:
``pyFIFA-play``